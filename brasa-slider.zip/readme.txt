=== Plugin Name ===
Contributors: MatheusGimenez, brasadesign
Donate link: http://brasa.art.br
Tags: slider, brasa, post slider
Requires at least: 4.5
Tested up to: 4.7
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Add a Slider with images, posts and pages to your pages with an easy-to-use shortcode!

== Description ==
After installing the plugin go to your dashboard and create a new slider. You have the possibility to search through your posts and pages in order to add them or add an image.

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/brasa-slider` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress
